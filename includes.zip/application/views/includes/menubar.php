<div class="content_wrap menu_bg">
		<div id="sub_nav_wrap" class="content">
<span class="preload1"></span>
<span class="preload2"></span>

<ul id="navM">
	<li class="top"><a href="<?php echo $base_url; ?>" class="top_link"><span>Home</span></a></li>
	<li class="top"><a href="#nogo2" id="products" class="top_link"><span class="down">Operator</span></a>
		<ul class="sub">
			<li><a href="<?php echo $base_url;?>bmpt/create_patient">Patient Panel</a></li>
			
		
		</ul>
	</li>
	<li class="top"><a href="#nogo22" id="services" class="top_link"><span class="down">Doctor</span></a>
		<ul class="sub">
			<li><a href="<?php echo $base_url;?>bmpt/doc_panel">Main Panel</a></li>
			<li><a href="<?php echo $base_url;?>bmpt/show_doctor">Doctor info</a></li>
            <li><a href="<?php echo $base_url;?>bmpt/show_all_patients_this">Patient info</a></li>
			
		</ul>
	</li>
    <li class="top"><a href="#nogo22" id="services" class="top_link"><span class="down">Admin</span></a>
		<ul class="sub">
        	<li><a href="<?php echo $base_url;?>bmpt/show_doctor_admin">Doctor Info</a></li>
			<li><a href="<?php echo $base_url;?>bmpt/show_operator">Operator Info</a></li>
			
	<li><a href="<?php echo $base_url;?>bmpt/show_patient">Patient Database</a></li>
      <li><a href="<?php echo $base_url;?>bmpt/medicine">Medicine Panel</a></li>		
		</ul>
	</li>
    
    
    
		</li>
	<li class="top"><a href="#nogo27" id="contacts" class="top_link"><span class="down">Contacts</span></a>
		<ul class="sub">
			<li><a href="#nogo28">Support</a></li>
			
		</ul>
	</li>
	
</ul>
 </div>
 </div>