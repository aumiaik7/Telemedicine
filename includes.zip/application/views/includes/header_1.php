<script>
	// Hide content onload, prevents JS flicker
	document.body.className += ' js-enabled';
</script>

<div id="header_wrap">
	<div id="header">
		<h1 id="logo">
			<a href="<?php echo $base_url; ?>" title="Telemedicine">
				<img src="<?php echo $includes_dir;?>images/logo1.png" alt="Telemedicine"/>
				<span class="img_rep">Telemedicine</span> 
			</a>
		</h1>
		 
		<ul id="nav">
			<li>
				<a href="<?php echo $base_url;?>">Home</a>
			</li>
			<li>
				<a href="<?php echo $base_url;?>bmpt/support">Contact</a>
			</li>
			<li>
				<a href="http://bmpt.du.ac.bd">About</a>
			</li>
		</ul> 

		<a href="http://bmpt.du.ac.bd" id="flexi_cart_ribbon">
			<div class="ribbon_text">			
				<p>
					Meet<br/>
					The<br/>
					Developer
				</p>
				<h6>BMPT</h6>
			</div>
		</a>
	</div>
</div>