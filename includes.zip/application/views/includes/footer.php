	<div class="content_wrap footer_bg">
		<div id="footer" class="content clearfix">
			<div class="float_l" style="margin-top:35px;">
				Copyright &copy; <?php echo date('Y');?>, Moti, All Rights Reserved.<br/>
			</div>
			<div class="float_r" style="margin-top:20px; text-align:center;">
				This website is designed and developed by<br/>
				<a href="http://bmpt.du.ac.bd">
					<img src="<?php echo $includes_dir; ?>images/bmpt1.png"/>
				</a>
			</div>
		</div>
	</div>