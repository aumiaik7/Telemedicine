
	
	<link rel="stylesheet" href="<?php echo $includes_dir;?>form_resource/view.css">
    <script src="<?php echo $includes_dir;?>form_resource/view.js"></script>
	<script src="<?php echo $includes_dir;?>form_resource/calendar.js"></script>
	
    
  
