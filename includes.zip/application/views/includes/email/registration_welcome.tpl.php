<html>
<body>
	<h1>Thankyou for Registering!</h1>
	
	<p>You login identity is: <?php echo $identity;?></p>
</body>
</html>