$(document).ready(function() {
	
var base_url = $('#base_url').val();

$('#form_container').load(base_url+'bmpt/center_');	


});